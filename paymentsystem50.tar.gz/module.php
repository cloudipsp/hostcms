<?php

$tmpDir = Market_Controller::instance()->tmpDir . DIRECTORY_SEPARATOR;

$aOptions = Market_Controller::instance()->options;

$aReplace = array();

$sLng = 'ru';
$aPossibleLanguages = array('en', 'ru');
$sSitePostfix = '';

foreach ($aOptions as $optionName => $optionValue)
{
	$aReplace['%' . $optionName . '%'] = $optionValue;
}

$Install_Controller = Install_Controller::instance();
$Install_Controller->setTemplatePath($tmpDir);

$oShop = Core_Entity::factory('Shop', $aOptions['shop_id']);

$aPaymentsystemi18n = array(
	'ru' => array(
		9 => array('file' => 'handler50.php', 'name' => 'FONDY Payment System', 'description' => 'FONDY — это многофункциональный платежный шлюз, который объединяет все способы онлайн оплаты HostCMS и позволяет бизнесу войти в мир электронной коммерции.'),
	),
	'en' => array(
		9 => array('file' => 'handler50.php', 'name' => 'FONDY Payment System', 'description' => 'Accept payments online in Europe. Payment Gateway FONDY is an online merchant service provider that helps you accept credit cards.'),
	)
);

// Платежные системы
foreach ($aPaymentsystemi18n[$sLng] as $iPaymentsystemId => $aPaymentsystem)
{
	$oShop_Payment_System = Core_Entity::factory('Shop_Payment_System');
	$oShop_Payment_System->name = $aPaymentsystem['name'];
	$oShop_Payment_System->description = $aPaymentsystem['description'];
	$oShop->add($oShop_Payment_System);

	$aReplace['Shop_Payment_System_Handler' . $iPaymentsystemId] = 'Shop_Payment_System_Handler' . $oShop_Payment_System->id;

	$sContent = $Install_Controller->loadFile($tmpDir . "tmp/" . $aPaymentsystem['file'], $aReplace);
	$oShop_Payment_System->savePaymentSystemFile($sContent);
}